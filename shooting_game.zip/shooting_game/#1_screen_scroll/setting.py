#ウィンドウの設定
screen_width = 600
screen_height = 600

#FPSの設定
FPS = 60

#色の設定
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)